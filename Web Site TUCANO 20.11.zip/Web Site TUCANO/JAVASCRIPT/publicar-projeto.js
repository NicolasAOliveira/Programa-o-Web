const apiKey = '3c6379f801d94c6da9e8004e5068503e';

// Função para buscar sugestões de local
document.querySelector('#local').addEventListener('input', function () {
    const query = this.value;

    if (query.length > 2) {
        fetch(`https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(query)}&key=${apiKey}&language=pt`)
            .then(response => response.json())
            .then(data => {
                const sugestoes = document.querySelector('#sugestoes-local');
                sugestoes.innerHTML = ''; // Limpar sugestões anteriores

                data.results.forEach(result => {
                    const li = document.createElement('li');
                    li.textContent = result.formatted;
                    li.addEventListener('click', function () {
                        document.querySelector('#local').value = result.formatted;
                        sugestoes.innerHTML = ''; // Limpar sugestões após seleção
                    });
                    sugestoes.appendChild(li);
                });
            })
            .catch(err => console.error('Erro ao buscar local:', err));
    }
});

// Função para publicar a oportunidade
document.querySelector('#formulario-publicacao').addEventListener('submit', function(evento) {
    evento.preventDefault();

    const titulo = document.querySelector('#titulo').value;
    const descricao = document.querySelector('#descricao').value;
    const valor = document.querySelector('#valor').value;
    const local = document.querySelector('#local').value;
    const dataInicio = document.querySelector('#dataInicio').value;
    const dataFim = document.querySelector('#dataFim').value;
    const horarioInicio = document.querySelector('#horarioInicio').value;
    const horarioFim = document.querySelector('#horarioFim').value;
    const status = document.querySelector('#status').checked ? "Ativo" : "Inativo";

    alert(`Oportunidade Publicada:\\nTítulo: ${titulo}\\nDescrição: ${descricao}\\nValor: ${valor}\\nLocal: ${local}\\nData: de ${dataInicio} até ${dataFim}\\nHorário: de ${horarioInicio} até ${horarioFim}\\nStatus: ${status}`);
});


document.querySelector('#formulario-publicacao').addEventListener('submit', function (evento) {
    evento.preventDefault();

    const categoria = document.querySelector('#categoria').value;
    const titulo = document.querySelector('#titulo').value;
    const descricao = document.querySelector('#descricao').value;
    const valor = document.querySelector('#valor').value;
    const local = document.querySelector('#local').value;
    const dataInicio = document.querySelector('#dataInicio').value;
    const dataFim = document.querySelector('#dataFim').value;
    const horarioInicio = document.querySelector('#horarioInicio').value;
    const horarioFim = document.querySelector('#horarioFim').value;
    const status = document.querySelector('#status').checked ? "Ativo" : "Inativo";

    alert(`Oportunidade Publicada:\\nCategoria: ${categoria}\\nTítulo: ${titulo}\\nDescrição: ${descricao}\\nValor: ${valor}\\nLocal: ${local}\\nData: de ${dataInicio} até ${dataFim}\\nHorário: de ${horarioInicio} até ${horarioFim}\\nStatus: ${status}`);
});
