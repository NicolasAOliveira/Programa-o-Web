// Simulando dados trazidos de uma API ou banco de dados
const vagaData = {
    title: "Serviço de Garçom - Cantina Italiana",
    date: "Hoje às 11:46",
    description: "Serviço de garçom para 1 ou 2 turnos, em restaurante italiano familiar.",
    requirements: [
      "Experiência prévia como garçom (mínimo 1 ano).",
      "Disponibilidade para trabalhar em turnos (manhã/tarde).",
      "Habilidade em lidar com público diverso.",
      "Pontualidade e responsabilidade."
    ],
    benefits: [
      "Refeição no local.",
      "Vale-transporte.",
      "Ambiente familiar e acolhedor."
    ],
    hours: "Manhã / Tarde",
    salary: "R$ 1.500,00",
    location: "Rua das Flores, 123, São Paulo, SP",
    category: "Restaurante e Atendimento",
    subcategory: "Serviço de Garçom",
    level: "Intermediário",
    visibility: "Público",
    mapUrl: "https://www.google.com/maps/embed?pb=..."
};

// Preenchendo os dados na página
document.getElementById("job-title").textContent = vagaData.title;
document.getElementById("job-date").textContent = vagaData.date;
document.getElementById("job-description").textContent = vagaData.description;

// Preenchendo listas (Requisitos e Benefícios)
vagaData.requirements.forEach(req => {
    const li = document.createElement("li");
    li.textContent = req;
    document.getElementById("job-requirements").appendChild(li);
});

vagaData.benefits.forEach(benefit => {
    const li = document.createElement("li");
    li.textContent = benefit;
    document.getElementById("job-benefits").appendChild(li);
});

// Preenchendo outras informações
document.getElementById("job-hours").textContent = vagaData.hours;
document.getElementById("job-salary").textContent = vagaData.salary;
document.getElementById("job-location").textContent = vagaData.location;
document.getElementById("job-category").textContent = vagaData.category;
document.getElementById("job-subcategory").textContent = vagaData.subcategory;
document.getElementById("job-level").textContent = vagaData.level;
document.getElementById("job-visibility").textContent = vagaData.visibility;

// Configurando o mapa
document.getElementById("job-map").src = vagaData.mapUrl;

// Evento de clique no botão "Candidatar-se"
document.getElementById("apply-btn").addEventListener("click", () => {
    const userId = 1; // ID do usuário logado (pode vir do sistema de autenticação)
    const vagaId = new URLSearchParams(window.location.search).get('id'); // ID da vaga atual

    // Enviar a candidatura para o back-end
    fetch('http://localhost:3000/candidatar', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId, vagaId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Candidatura realizada com sucesso!");
        } else {
            alert("Erro ao se candidatar. Tente novamente.");
        }
    })
    .catch(error => console.error("Erro ao enviar candidatura:", error));
});
