app.post('/candidatar', (req, res) => {
    const { userId, vagaId } = req.body;

    if (!userId || !vagaId) {
        return res.status(400).json({ success: false, message: 'Dados incompletos.' });
    }

    const query = 'INSERT INTO candidaturas (user_id, vaga_id) VALUES (?, ?)';
    db.query(query, [userId, vagaId], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ success: false, message: 'Erro ao registrar candidatura.' });
        }

        res.json({ success: true, message: 'Candidatura registrada com sucesso!' });
    });
});
