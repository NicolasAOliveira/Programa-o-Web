async function searchProducts() {
    const term = document.getElementById('search-input').value;
    try {
        const response = await fetch(`/api/search?term=${term}`);
        const products = await response.json();
        displayResults(products);
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
    }
}

function displayResults(products) {
    const resultsDiv = document.getElementById('search-results');
    resultsDiv.innerHTML = '';  // Limpa resultados anteriores
    products.forEach(product => {
        resultsDiv.innerHTML += `
            <div class="product-item">
                <img src="${product.imagem_url}" alt="${product.nome}">
                <h3>${product.nome}</h3>
                <p>${product.descricao}</p>
                <span>${product.preco}</span>
            </div>`;
    });
}
