// Validação do formulário de login
document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const email = document.getElementById('email');
    const senha = document.getElementById('senha');
    const manterConectado = document.getElementById('manter-conectado').checked;
    let valid = true;

    // Remover mensagens de erro anteriores
    email.classList.remove('error');
    senha.classList.remove('error');

    // Verificação dos campos de email e senha
    if (!email.value) {
        email.classList.add('error');
        valid = false;
    }
    if (!senha.value) {
        senha.classList.add('error');
        valid = false;
    }
    if (!valid) {
        alert('Por favor, preencha todos os campos.');
        return;
    }

    // Indicador de progresso no botão de login
    const loginButton = document.querySelector('.login-btn');
    loginButton.textContent = 'Entrando...';
    loginButton.disabled = true;

    // Simulação de tempo de carregamento para o login
    setTimeout(() => {
        alert('Login efetuado com sucesso!');
        loginButton.textContent = 'Entrar';
        loginButton.disabled = false;
        window.location.href = 'dashboard.html'; // Redireciona para a página de dashboard
    }, 2000); // Tempo de carregamento simulado
});

// Carregar scripts de login social sob demanda
document.querySelector('.facebook-btn').addEventListener('click', loadFacebookScript);
document.querySelector('.google-btn').addEventListener('click', loadGoogleScript);

// Função para carregar o SDK do Facebook
function loadFacebookScript() {
    if (!document.getElementById('facebook-sdk')) {
        const script = document.createElement('script');
        script.id = 'facebook-sdk';
        script.src = 'https://connect.facebook.net/en_US/sdk.js';
        document.body.appendChild(script);
    }
}

// Função para carregar o SDK do Google
function loadGoogleScript() {
    if (!document.getElementById('google-sdk')) {
        const script = document.createElement('script');
        script.id = 'google-sdk';
        script.src = 'https://accounts.google.com/gsi/client';
        document.body.appendChild(script);
    }
}

document.addEventListener("DOMContentLoaded", function() {
    // Redireciona para a página de cadastro
    document.getElementById('cadastro-btn').addEventListener('click', function(event) {
        event.preventDefault(); // Impede o comportamento padrão do link
        window.location.href = 'recuperacao_senha.html'; // Redireciona para a página de recuperação de senha
    });
});

