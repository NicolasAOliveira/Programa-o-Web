app.get('/api/search', async (req, res) => {
    const term = req.query.term;
    try {
        const products = await db.query(
            `SELECT * FROM produtos WHERE 
            nome LIKE ? OR 
            descricao LIKE ? OR 
            categoria LIKE ? OR 
            marca LIKE ? OR 
            tags LIKE ?`, 
            [`%${term}%`, `%${term}%`, `%${term}%`, `%${term}%`, `%${term}%`]
        );
        res.json(products);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar produtos' });
    }
});
