document.addEventListener("DOMContentLoaded", function() {
    const stepEmail = document.getElementById("step-email");
    const stepCode = document.getElementById("step-code");
    const stepResetPassword = document.getElementById("step-reset-password");

    const emailInput = document.getElementById("email");
    const verificationCodeInput = document.getElementById("verification-code");
    const newPasswordInput = document.getElementById("new-password");
    const confirmPasswordInput = document.getElementById("confirm-password");

    const sendCodeBtn = document.getElementById("send-code-btn");
    const verifyCodeBtn = document.getElementById("verify-code-btn");
    const resetPasswordBtn = document.getElementById("reset-password-btn");

    const emailFeedback = document.getElementById("email-feedback");
    const codeFeedback = document.getElementById("code-feedback");
    const passwordFeedback = document.getElementById("password-feedback");

    const strengthBarSections = document.getElementsByClassName("bar-section");
    const strengthLabel = document.getElementById("strength-label");

    let generatedCode = null;
    let codeAttempts = 0;
    const maxCodeAttempts = 3;

    // Simula um "banco de dados" de emails cadastrados
    const registeredEmails = ["teste@gmail.com", "lucca.trivellato2004@gmail.com", "usuario@example.com"];

    // Função para enviar o código de verificação
    sendCodeBtn.addEventListener("click", function() {
        if (validateEmail(emailInput.value)) {
            if (registeredEmails.includes(emailInput.value)) {
                generatedCode = generateVerificationCode();
                // Exibe o código na tela para teste
                document.getElementById('code-display').innerText = `Seu código de verificação: ${generatedCode}`;
                stepEmail.style.display = "none";
                stepCode.style.display = "block";
                emailFeedback.innerText = "";
            } else {
                emailFeedback.innerText = "Email não cadastrado.";
            }
        } else {
            emailFeedback.innerText = "Por favor, insira um email válido.";
        }
    });

    // Verifica o código digitado
    verifyCodeBtn.addEventListener("click", function() {
        if (verificationCodeInput.value === generatedCode) {
            stepCode.style.display = "none";
            stepResetPassword.style.display = "block";
            codeFeedback.innerText = "";
        } else {
            codeAttempts++;
            if (codeAttempts >= maxCodeAttempts) {
                codeFeedback.innerText = "Número máximo de tentativas excedido. Por favor, solicite um novo código.";
                verifyCodeBtn.disabled = true;
            } else {
                codeFeedback.innerText = `Código incorreto. Tentativas restantes: ${maxCodeAttempts - codeAttempts}`;
            }
        }
    });

    // Verifica a força da senha em tempo real
    newPasswordInput.addEventListener("input", function() {
        const strength = calculatePasswordStrength(newPasswordInput.value);

        // Limpa e preenche a barra de acordo com a força da senha
        resetStrengthBar();
        for (let i = 0; i < strength; i++) {
            strengthBarSections[i].style.backgroundColor = getColorByIndex(i);
        }
        strengthLabel.innerText = getStrengthLabel(strength);
    });

    // Reseta a barra para deixar todas as seções vazias
    function resetStrengthBar() {
        for (let i = 0; i < strengthBarSections.length; i++) {
            strengthBarSections[i].style.backgroundColor = "#ddd";
        }
    }

    // Verifica se as senhas coincidem em tempo real
    confirmPasswordInput.addEventListener("input", function() {
        if (newPasswordInput.value !== confirmPasswordInput.value) {
            confirmPasswordInput.classList.add("invalid");
            passwordFeedback.innerText = "As senhas não coincidem.";
        } else {
            confirmPasswordInput.classList.remove("invalid");
            passwordFeedback.innerText = "";
        }
    });

    // Evento de clique no botão de redefinir senha
    resetPasswordBtn.addEventListener("click", function() {
        if (newPasswordInput.value !== confirmPasswordInput.value) {
            passwordFeedback.innerText = "As senhas não coincidem.";
        } else if (calculatePasswordStrength(newPasswordInput.value) < 3) {
            passwordFeedback.innerText = "A senha deve ser forte ou muito forte.";
        } else {
            // Aqui você poderia atualizar a senha no banco de dados
            alert("Senha redefinida com sucesso!");
            window.location.href = '../HTML/login.html';
        }
    });

    // Função para gerar o código de verificação
    function generateVerificationCode() {
        return Math.floor(100000 + Math.random() * 900000).toString(); // Gera um código numérico de 6 dígitos
    }

    // Critérios para calcular a força da senha
    function calculatePasswordStrength(password) {
        let strength = 0;

        if (password.length >= 8) strength++;
        if (password.match(/[a-z]+/)) strength++;
        if (password.match(/[A-Z]+/)) strength++;
        if (password.match(/[0-9]+/)) strength++;
        if (password.match(/[\W_]+/)) strength++;

        return strength;
    }

    // Define a cor da barra por índice de força
    function getColorByIndex(index) {
        const colors = ["red", "orange", "yellow", "green", "darkgreen"];
        return colors[index];
    }

    // Define o rótulo de força da senha
    function getStrengthLabel(strength) {
        switch (strength) {
            case 1:
                return "Muito Fraca";
            case 2:
                return "Fraca";
            case 3:
                return "Média";
            case 4:
                return "Forte";
            case 5:
                return "Muito Forte";
            default:
                return "Muito Fraca";
        }
    }

    // Valida o email
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }
});
