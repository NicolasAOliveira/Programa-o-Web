document.addEventListener("DOMContentLoaded", function () {
    // Redireciona para a página de busca
    const searchBtn = document.getElementById('search-btn');
    if (searchBtn) {
        searchBtn.addEventListener('click', function () {
            window.location.href = '../HTML/busca.html';
        });
    }

    // Redireciona para a página de login
    const loginLink = document.getElementById('login-link');
    if (loginLink) {
        loginLink.addEventListener('click', function (event) {
            event.preventDefault();
            window.location.href = '../HTML/login.html';
        });
    }

    // Redireciona para a página de busca ao clicar no botão "Buscar Trabalhos"
    const buscarTrabalhosBtn = document.getElementById('buscar-trabalhos-btn');
    if (buscarTrabalhosBtn) {
        buscarTrabalhosBtn.addEventListener('click', function () {
            window.location.href = '../HTML/busca.html';
        });
    }

    // Redireciona para a página de cadastro
    const cadastroLink = document.getElementById('cadastro-link');
    if (cadastroLink) {
        cadastroLink.addEventListener('click', function (event) {
            event.preventDefault();
            window.location.href = '../HTML/cadastro.html';
        });
    }

    // Redireciona para a página de gerenciamento de conteúdo ao clicar no ícone de usuário
    const userIcon = document.getElementById('user-icon');
    if (userIcon) {
        userIcon.addEventListener('click', function () {
            window.location.href = '../HTML/gerenciamento_de_conteudo.html';
        });
    }

    // Redireciona para a página de notificações ao clicar em qualquer item de notificação
    const notificacaoItems = document.querySelectorAll('.notificacao-item');
    if (notificacaoItems.length > 0) {
        notificacaoItems.forEach(item => {
            item.addEventListener('click', function () {
                window.location.href = '../HTML/notificacoes.html';
            });
        });
    }

    // Redireciona para a tela principal ao clicar no logo
    const logoLinks = document.querySelectorAll('.logo a');
    if (logoLinks.length > 0) {
        logoLinks.forEach(item => {
            item.addEventListener('click', function (event) {
                event.preventDefault();
                window.location.href = '../HTML/home.html';
            });
        });
    }
});
