function openJobPage(title, schedule, description, salary) {
    // Cria uma nova janela
    const jobWindow = window.open("", "_blank");
  
    // Conteúdo HTML da nova página
    const pageContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${title} - Vaga</title>
        <link rel="stylesheet" href="../CSS/header.css">
        <link rel="stylesheet" href="../CSS/footer.css">
        <style>
          /* Estilos específicos para o conteúdo da vaga */
          body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
          main { padding: 20px; }
          .job-details h1 { font-size: 24px; color: #2C3E50; }
          .job-details h2 { font-size: 18px; color: #555; }
          .job-details p { font-size: 16px; color: #333; }
          .back-button { margin-top: 20px; padding: 10px 20px; background-color: #2C3E50; color: white; border: none; cursor: pointer; }
        </style>
      </head>
      <body>
        <!-- Cabeçalho -->
        <header>
          <div class="logo">
              <a href="../HTML/index.html">
                  <img src="../IMG/logo.png" alt="Logo Tucano" class="logo-image">
              </a>
          </div>
          <div class="search-bar">
              <input type="text" placeholder="Buscar">
              <button><img src="../IMG/search-icon.png" alt="Buscar"></button>
          </div>
          <nav>
              <a href="#">Login</a>
              <a href="#">Cadastre-se</a>
          </nav>
          <div class="header-icons">
              <button id="notificacoes-btn" class="icon-bell-btn">
                <img src="../IMG/bell-icon.png" alt="Notificações" class="icon-bell">
              </button>
              <img src="../IMG/profile-pic.png" alt="Perfil" class="profile-pic">
          </div>
        </header>
  
        <!-- Conteúdo principal da vaga -->
        <main class="job-details">
          <h1>${title}</h1>
          <h2>Detalhes da Vaga</h2>
          <p><strong>Horário:</strong> ${schedule}</p>
          <p><strong>Descrição:</strong> ${description}</p>
          <p><strong>Salário:</strong> ${salary}</p>
          <button class="back-button" onclick="window.close()">Voltar</button>
        </main>
  
        <!-- Rodapé -->
        <footer class="site-footer">
            <p>&copy; 2024 TUCANO LLC - Todos os direitos reservados.</p>
            <div class="footer-links">
                <a href="#">Política de Privacidade</a>
                <a href="#">Termos de Uso</a>
            </div>
        </footer>
      </body>
      </html>
    `;
  
    // Escreve o conteúdo na nova janela
    jobWindow.document.write(pageContent);
    jobWindow.document.close();
  }
  