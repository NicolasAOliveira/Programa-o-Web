from app import db
from werkzeug.security import generate_password_hash, check_password_hash

class Usuario(db.Model):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    senha_hash = db.Column(db.String(128), nullable=False)
    tipo = db.Column(db.Enum('Pessoa', 'Empresa'), nullable=False)
    data_cadastro = db.Column(db.DateTime, default=db.func.current_timestamp())

    def set_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

    def check_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)

class Pessoa(db.Model):
    __tablename__ = 'pessoas'
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), primary_key=True)
    nome = db.Column(db.String(255), nullable=False)
    cpf = db.Column(db.String(14), unique=True, nullable=False)
    telefone = db.Column(db.String(15))
    disponibilidade = db.Column(db.String(50))
    cep = db.Column(db.String(9))
    endereco = db.Column(db.String(255))
    numero = db.Column(db.String(10))
    complemento = db.Column(db.String(100))
    bairro = db.Column(db.String(100))
    cidade = db.Column(db.String(100))
    estado = db.Column(db.String(2))
    usuario = db.relationship('Usuario', backref=db.backref('pessoa', uselist=False))

class Empresa(db.Model):
    __tablename__ = 'empresas'
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), primary_key=True)
    razao_social = db.Column(db.String(255), nullable=False)
    cnpj = db.Column(db.String(18), unique=True, nullable=False)
    porte = db.Column(db.String(50))
    website = db.Column(db.String(255))
    cep = db.Column(db.String(9))
    endereco = db.Column(db.String(255))
    numero = db.Column(db.String(10))
    complemento = db.Column(db.String(100))
    bairro = db.Column(db.String(100))
    cidade = db.Column(db.String(100))
    estado = db.Column(db.String(2))
    usuario = db.relationship('Usuario', backref=db.backref('empresa', uselist=False))

class Oportunidade(db.Model):
    __tablename__ = 'oportunidades'
    id_oportunidade = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(255), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    valor = db.Column(db.Float, nullable=False)
    local = db.Column(db.String(255), nullable=False)
    categoria = db.Column(db.String(100), nullable=False)
    data_inicio = db.Column(db.Date, nullable=False)
    data_fim = db.Column(db.Date, nullable=False)
    horario_inicio = db.Column(db.Time, nullable=False)
    horario_fim = db.Column(db.Time, nullable=False)
    status = db.Column(db.Boolean, default=True, nullable=False)

    # Relacionamento com usuários (empresas ou pessoas)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    usuario = db.relationship('Usuario', backref=db.backref('oportunidades', lazy=True))