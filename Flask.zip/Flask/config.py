import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'sua_chave_secreta_aqui'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:Ng102783%@localhost:3306/bdflask'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


"""
                    TUTORIAL PARA BAITOLAS
TODOS OS COMANDOS E OS 'PASSO A PASSO' DEVEM SER FEITOS NO TERMINAL

    PASSO A PASSO: CRIAR E ATUALIZAR
        1. Abrir o terminal e selecionar a pasta correta. (Atalho: Ctrl + Shift + ' )
        2. Cole o codigo para baixar o flask e suas dependencias. (Comando: pip install Flask flask_sqlalchemy flask_migrate pymysql)
        3. Inicia a migraçao criando a pasta com o comando. (Comando: flask db init)
        4. Salve as mudanças da imigraçao com as mudanças necessarias. (Comando: flask db migrate -m "Mensagem explicativa")
            4,1. A "Mensagem explicativa" é apenas para controle, coloca o nome da atualizaçao ex: "pagina vagas" ou "pagina cadastro"
        5.Executar as mudanças para serem adicionadas ao banco. (Comando: flask db upgrade)

    PASSO A PASSO: EXECUTAR PARA TESTE
        0. Para executar o arquivo agora nao é mais pela pasta e abrir o arquivo, deve ser executado todas as vezes o comando para rodar os codigos.
        1. Execute o comando para iniciar a conexao com o flask. (Codigo: python -m flask --app app run)
        2. Vai carregar uns trem ai, procure o 'Running on' e abra a pagina executada. (Para abrir a pagina segure 'Ctrl' e clique no endereço 'http:[...]')
        3. A conexao permanece ativa até ser encerrada. (Para encerrar a coneçao, no terminal, aperte 'Ctrl + C')

    # OBS. cada vez que for feita uma mudança no codigo encerre a comunicaçao com o flask e à inicie novamente para ver as mudanças.

"""