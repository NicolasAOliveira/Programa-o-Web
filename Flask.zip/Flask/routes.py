from app import app, db
from flask import render_template, redirect, url_for, flash, request, session
from models import Usuario, Pessoa, Empresa

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        tipo = request.form.get('tipo')  # 'Pessoa' ou 'Empresa'
        email = request.form.get('email')
        senha = request.form.get('senha')
        # Verificar se o usuário já existe
        usuario_existente = Usuario.query.filter_by(email=email).first()
        if usuario_existente:
            flash('Email já cadastrado.', 'danger')
            return redirect(url_for('cadastro'))

        # Criar novo usuário
        usuario = Usuario(email=email, tipo=tipo)
        usuario.set_senha(senha)
        db.session.add(usuario)
        db.session.commit()

        usuario_id = usuario.id

        if tipo == 'Pessoa':
            # Receber dados específicos de Pessoa
            nome = request.form.get('nome')
            cpf = request.form.get('cpf')
            telefone = request.form.get('telefone')
            disponibilidade = request.form.get('disponibilidade')
            cep = request.form.get('cep')
            endereco = request.form.get('endereco')
            numero = request.form.get('numero')
            complemento = request.form.get('complemento')
            bairro = request.form.get('bairro')
            cidade = request.form.get('cidade')
            estado = request.form.get('estado')

            # Inserir na tabela pessoas
            pessoa = Pessoa(
                usuario_id=usuario_id,
                nome=nome,
                cpf=cpf,
                telefone=telefone,
                disponibilidade=disponibilidade,
                cep=cep,
                endereco=endereco,
                numero=numero,
                complemento=complemento,
                bairro=bairro,
                cidade=cidade,
                estado=estado
            )
            db.session.add(pessoa)
            db.session.commit()
        else:
            # Receber dados específicos de Empresa
            razao_social = request.form.get('razao_social')
            cnpj = request.form.get('cnpj')
            porte = request.form.get('porte')
            website = request.form.get('website')
            cep = request.form.get('cep')
            endereco = request.form.get('endereco')
            numero = request.form.get('numero')
            complemento = request.form.get('complemento')
            bairro = request.form.get('bairro')
            cidade = request.form.get('cidade')
            estado = request.form.get('estado')

            # Inserir na tabela empresas
            empresa = Empresa(
                usuario_id=usuario_id,
                razao_social=razao_social,
                cnpj=cnpj,
                porte=porte,
                website=website,
                cep=cep,
                endereco=endereco,
                numero=numero,
                complemento=complemento,
                bairro=bairro,
                cidade=cidade,
                estado=estado
            )
            db.session.add(empresa)
            db.session.commit()

        flash('Cadastro realizado com sucesso! Faça login.', 'success')
        return redirect(url_for('login'))

    return render_template('cadastro.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        usuario = Usuario.query.filter_by(email=email).first()
        if usuario and usuario.check_senha(senha):
            session['usuario_id'] = usuario.id
            session['tipo'] = usuario.tipo
            flash('Login efetuado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Email ou senha incorretos.', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')
@app.route('/logout')
def logout():
    session.clear()
    flash('Você saiu da sua conta.', 'info')
    return redirect(url_for('login'))
