document.addEventListener("DOMContentLoaded", function() {
    // Redireciona para a página de busca
    document.getElementById('search-btn').addEventListener('click', function() {
        window.location.href = '../HTML/busca.html';
    });

    // Redireciona para a página de login
    document.getElementById('login-link').addEventListener('click', function(event) {
        event.preventDefault();
        window.location.href = '../HTML/login.html';
    });

    // Redireciona para a página de busca ao clicar no botão "Buscar Trabalhos"
    document.getElementById('buscar-trabalhos-btn').addEventListener('click', function() {
        window.location.href = '../HTML/busca.html';
    });

    // Redireciona para a página de cadastro
    document.getElementById('cadastro-link').addEventListener('click', function(event) {
        event.preventDefault();
        window.location.href = '../HTML/cadastro.html';
    });

    // Redireciona para a página de gerenciamento de conteúdo ao clicar no ícone de usuário
    document.getElementById('user-icon').addEventListener('click', function() {
        window.location.href = '../HTML/gerenciamento_de_conteudo.html';
    });

    // Redireciona para a página de notificações ao clicar em qualquer item de notificação
    document.querySelectorAll('.notificacao-item').forEach(item => {
        item.addEventListener('click', function() {
            window.location.href = '../HTML/notificacoes.html';
        });
    });

    // Redireciona para a tela principal ao clicar no logo
    document.querySelectorAll('.logo a').forEach(item => {
        item.addEventListener('click', function() {
            window.location.href = '../HTML/home.html'; 
        });
    });
});